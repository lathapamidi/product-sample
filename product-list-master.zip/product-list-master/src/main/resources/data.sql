--data
insert into product(id, name, description,  price) values(101, 'Laptop', 'Dell 5250 Precision series', 1100);
insert into product(id, name, description,  price) values(102, 'Phone', 'Apple 12 series', 1600);
insert into product(id, name, description,  price) values(103, 'Television', 'Samsung 32" wide view', 1800);
insert into product(id, name, description,  price) values(104, 'Mashing Machine', 'LG 8KG front load', 2200);
insert into product(id, name, description,  price) values(105, 'Microwave', 'LG 12 Liter charcoal', 1700);
insert into product(id, name, description,  price) values(106, 'Grinder', 'FB 1HP Grinder', 500);