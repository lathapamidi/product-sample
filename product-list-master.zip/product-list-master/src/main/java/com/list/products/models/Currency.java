package com.list.products.models;

public enum Currency {
	USD , INR, GBP, EUR,CNY, AUD
}
